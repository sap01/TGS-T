.onLoad <- function(lib, pkg) {
  dotpath <- as.character(Sys.getenv("R_DOTVIEWER"))
  set.seed(02081969)
}

